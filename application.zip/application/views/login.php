<header>
<div class="container-fluid">
	<div class="row">
		<div class="col-12 text-center">
			<img src="<?= base_URL()?>/assets/img/Qval-admyo.jpg" alt="">
		</div>
	</div>
</div>
</header>
<div class="container m-t-60">
	<div class="row">
		<div class="col-5 centrar-h">
			<div class="card w-100" style="width: 18rem;">
			  <div class="card-body">
			    <h5 class="card-title">LOGIN QVAL</h5>
			    <div class="form-grpup">
			    	<label for="">Usuario</label>
			    	<input type="text" id="user" class="form-control">
			    </div>
			    <div class="form-grpup">
			    	<label for="">Contraseña</label>
			    	<input type="password" id="pas" class="form-control">
			    </div>
			    <div class="alert alert-info m-t-30" >
			    	Bienvenido a Qval
			    </div>
			    <button id="btn-login" class="btn btn-primary m-t-30">Aceptar</button>
			  </div>
			</div>

		</div>
	</div>
</div>